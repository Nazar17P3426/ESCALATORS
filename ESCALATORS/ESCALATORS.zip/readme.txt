     eeeeee
    e
   eeeeee
  e
 eeeeee scalators.exe

By The Unknown Two and N17Pro38

rated damage: Destructive

Made In c++

simple payload!